<?php

namespace App\Models;

use CodeIgniter\Model;

class m_quiz extends Model
{
    public function getQuestionsParent()
    {
        try {
            // Charge la base de données
            $db = db_connect();

            // Requête pour récupérer toutes les questions
            $query = $db->table('question_parent')
                ->select('id_question, question, rep_correct')
                ->get();

            return $query->getResultArray();

        } catch (\Exception $e) {
            // Gérer l'exception
            die('Une exception s\'est produite: ' . $e->getMessage());
        }
    }

    public function getQuestionsEnfant()
    {
        try {
            // Charge la base de données
            $db = db_connect();

            // Requête pour récupérer toutes les questions
            $query = $db->table('question_enfant')
                ->select('id_question, question, rep_correct')
                ->get();

            return $query->getResultArray();

        } catch (\Exception $e) {
            // Gérer l'exception
            die('Une exception s\'est produite: ' . $e->getMessage());
        }
    }

}