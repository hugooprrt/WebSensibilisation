<?php

namespace App\Models;

use CodeIgniter\Database\Exceptions\DatabaseException;
use CodeIgniter\Model;

class m_user extends Model
{
    function createUser($prenom, $nom, $age, $login, $mail, $mdp)
    {
        try {
            $db = db_connect();

            $stmt1 = "SET @p0 = ?";
            $stmt2 = "SET @p1 = ?";
            $stmt3 = "SET @p2 = ?";
            $stmt4 = "SET @p3 = ?";
            $stmt5 = "SET @p4 = ?";
            $stmt6 = "SET @p5 = ?";

            $db->query($stmt1, [$prenom]);
            $db->query($stmt2, [$nom]);
            $db->query($stmt3, [$age]);
            $db->query($stmt4, [$login]);
            $db->query($stmt5, [$mail]);
            $db->query($stmt6, [$mdp]);

            $query = "SELECT `func_createUser`(@p0, @p1, @p2, @p3, @p4, @p5) AS `func_createUser`";
            $result = $db->query($query);

            if ($result) {
                return $result->getResult()[0]->func_createUser;
            } else {
                return 'Erreur lors de l\'exécution de la requête';
            }
        } catch (mysqli_sql_exception $e) {
            $errorCode = $e->getCode();
            $errorMessage = $e->getMessage();

            return "Erreur : $errorCode - Message : $errorMessage";
        }
    }

    function loginUser($login)
    {
        try {
            $db = db_connect();

            $stmt1 = "SET @p0 = ?";

            $db->query($stmt1, [$login]);

            $query = "CALL `proc_login`(@p0)";

            $result = $db->query($query);

            if ($result) {
                $resultArray = $result->getResult();

                if (count($resultArray) > 0) {
                    if (property_exists($resultArray[0], 'mot_de_passe')) {
                        return $resultArray[0];
                    } else {
                        return -1;
                    }
                } else {
                    return -1;
                }
            } else {
                return -1;
            }
        } catch (mysqli_sql_exception $e) {
            $errorCode = $e->getCode();
            $errorMessage = $e->getMessage();

            return "Erreur : $errorCode - Message : $errorMessage";
        }
    }
}