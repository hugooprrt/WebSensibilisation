<?php

namespace App\Models;

use CodeIgniter\Model;

class m_contact extends Model
{
    protected $table = 'contact';

    protected $allowedFields = ['nom', 'email', 'message'];

    /**
     * Insère les informations du formulaire de contact dans la base de données.
     *
     * @param array $data Les données du formulaire de contact à insérer.
     * @return bool True si l'insertion réussit, sinon false.
     */
    public function insertInfo($data)
    {
        try {
            // Insérer les données dans la base de données
            $this->insert($data);
            return true; // Succès
        } catch (\Exception $e) {
            // Gérer l'exception
            return false; // Échec
        }
    }

}