<?php

namespace App\Models;

use CodeIgniter\Model;

class m_conseil extends Model
{
    public function getImagePegiJeux($pegiId) {
        try {
            // Connexion à la base
            $db = db_connect();
            if ($db->connect_errno) {
                throw new \Exception('Erreur de connexion à la base de données: ' . $db->connect_error);
            }

            // Requête pour chercher une image
            $query = $db->table('pegi')
                ->select('jeux_image, pegi_image')
                ->where('id', $pegiId)
                ->orderBy('jeux_image, pegi_image','RANDOM')
                ->limit(1)
                ->get();

            if ($query->getNumRows() > 0) {
                // Vérifiez s'il y a des résultats avant de les récupérer
                $reponse = $query->getRowArray(); // Utilisez getRowArray() pour obtenir un tableau associatif
                return $reponse;
            } else {
                return null; // Retournez null si aucune donnée n'est trouvée
            }

        } catch (\Exception $e) {
            // Gérer l'exception
            die('Une exception s\'est produite: ' . $e->getMessage());
        }
    }

}