<?php

namespace App\Models;

use CodeIgniter\Model;

class m_escroquerie extends Model
{
    public function getLesEscroqueries() {
        try {
            // Connexion à la base
            $db = db_connect();
            if ($db->connect_errno) {
                throw new \Exception('Erreur de connexion à la base de données: ' . $db->connect_error);
            }

            // Requête pour chercher un enregistrement aléatoire
            $query = $db->table('escroqueries')
            ->select('nom_escroquerie, explication')
            ->orderBy('nom_escroquerie','RANDOM')
            ->limit(1)
            ->get();

            if($query->getFieldCount() > 0)
            {
                $reponse = $query->getResult();
            }

            return $reponse;


        } catch (\Exception $e) {
            // Gérer l'exception
            die('Une exception s\'est produite: ' . $e->getMessage());
        }
    }
}