<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\m_quiz;

class c_quiz extends BaseController
{
    public function index(): string
    {
        return view('v_header')
            . view('v_quiz')
            . view('v_footer');
    }


    public function parent(): string
    {
        // Vérifier si la session pour le quiz parent existe
        if (!session()->has('quiz_parent')) {
            // Si non, initialiser la session
            session()->set('quiz_parent', [
                'current_question' => 0,
                'correct_answers' => 0,
            ]);
        }

        // Récupérer le modèle de quiz
        $quizModel = new m_quiz();

        // Récupérer toutes les questions disponibles pour le thème parent
        $allQuestions = $quizModel->getQuestionsParent();

        // Vérifier si des questions sont disponibles
        if (empty($allQuestions)) {
            return view('v_header') . 'Aucune question disponible pour le thème parent.' . view('v_footer');
        }

        // Vérifier si la session des questions sélectionnées existe
        if (!session()->has('selected_questions')) {
            // Si non, mélanger les questions et sélectionner les 15 premières
            shuffle($allQuestions);
            $selectedQuestions = array_slice($allQuestions, 0, 15);
            session()->set('selected_questions', $selectedQuestions);
        } else {
            // Sinon, récupérer les questions sélectionnées depuis la session
            $selectedQuestions = session('selected_questions');
        }

        // Récupérer l'état actuel du quiz depuis la session
        $quizState = session('quiz_parent');

        // Vérifier si la méthode est appelée en mode POST (l'utilisateur a répondu à une question)
        if ($this->request->getMethod() === 'post') {
            // Incrémenter le compteur de réponses correctes si la réponse est vraie
            if ($this->request->getPost('answer') === 'true') {
                $quizState['correct_answers']++;
            }

            // Passer à la question suivante
            $quizState['current_question']++;

            // Vérifier si nous avons atteint la fin du quiz
            if ($quizState['current_question'] >= 15) {
                // Si oui, afficher la vue de fin de quiz avec le score
                return view('v_header') . view('v_quizFin', ['correct_answers' => $quizState['correct_answers']]) . view('v_footer');
            }
        }

        // Mettre à jour la session avec l'état actuel du quiz
        session()->set('quiz_parent', $quizState);

        // Récupérer la question actuelle à partir des questions sélectionnées
        $currentQuestion = $selectedQuestions[$quizState['current_question']];

        // Afficher la vue du quiz avec la question actuelle
        return view('v_header') . view('v_parent', ['question_parent' => $currentQuestion]) . view('v_footer');
    }


/*// Méthode pour afficher la question actuelle du quiz
    private function afficheQuestionParent()
    {
        // Récupérer l'état actuel du quiz depuis la session
        $quizState = session('quiz_parent');

        // Récupérer les questions sélectionnées depuis la session
        $selectedQuestions = session('selected_questions');

        // Récupérer l'index de la question actuelle
        $currentQuestionIndex = $quizState['current_question'];

        // Vérifier si la question actuelle est la dernière question
        if ($currentQuestionIndex >= 14) { // Si 14 car les indices commencent à 0
            // Afficher le score final et terminer le quiz
            return view('v_header')
                . view('v_quizFin', ['correct_answers' => $quizState['correct_answers']])
                . view('v_footer');
        }

        // Récupérer la question actuelle
        $currentQuestion = $selectedQuestions[$currentQuestionIndex];

        // Afficher la vue du quiz avec la question actuelle
        return view('v_header')
            . view('v_parent', ['question_parent' => $currentQuestion])
            . view('v_footer');
    }*/


    public function enfant(): string
    {
        // Réinitialiser la session spécifique au quiz enfant
        session()->remove('quiz_enfant');

        // Initialisation de la session pour le quiz enfant
        session()->set('quiz_enfant', [
            'current_question' => 0,
            'correct_answers' => 0,
        ]);

        $quizModel = new m_quiz();

        // Récupérer toutes les questions disponibles
        $allQuestions = $quizModel->getQuestionsEnfant();

        // Vérifier si le tableau de questions est vide
        if (empty($allQuestions)) {
            return view('v_header')
                . 'Aucune question disponible pour le thème enfant.'
                . view('v_footer');
        }

        // Mélanger les questions de manière aléatoire
        shuffle($allQuestions);

        // Limiter le nombre de questions à 15
        $selectedQuestions = array_slice($allQuestions, 0, 15);

        // Stocker les questions sélectionnées en session
        session()->set('selected_questions', $selectedQuestions);

        // Afficher la première question du quiz
        return $this->afficheQuestionEnfant();
    }


    // Méthode pour afficher la question actuelle du quiz
    private function afficheQuestionEnfant()
    {
            // Récupérer l'état actuel du quiz depuis la session
            $quizState = session('quiz_enfant');

            // Récupérer les questions sélectionnées depuis la session
            $selectedQuestions = session('selected_questions');

            // Récupérer l'index de la question actuelle
            $currentQuestionIndex = $quizState['current_question'];

            // Récupérer la question actuelle
            $currentQuestion = $selectedQuestions[$currentQuestionIndex];

            // Afficher la vue du quiz avec la question actuelle
            return view('v_header')
                . view('v_enfant', ['question_enfant' => $currentQuestion])
                . view('v_footer');
    }
}