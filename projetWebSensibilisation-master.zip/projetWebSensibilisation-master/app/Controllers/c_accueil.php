<?php

namespace App\Controllers;

use App\Controllers\BaseController;

use App\Models\m_escroquerie;

class c_accueil extends BaseController
{
    public function index(): string
    {
        $data['recupEscroquerie'] = $this->LesEscroqueries();

        return
            view( 'v_header')
            .view('v_accueil',$data)
            .view("v_footer");

    }

    public function LesEscroqueries() : String
    {
        $modelEscroquerie = new m_escroquerie();
        $recup = $modelEscroquerie->getLesEscroqueries();

        // gestion des données à transmettre à la vue
        // appeler la méthode sur le modèle
        $data['nomEscroquerie'] = $recup[0]->nom_escroquerie;
        $data['expEscroquerie'] = $recup[0]->explication;

        //var_dump($recup);

        return view('v_header')
            . view('v_accueil', $data)
            . view('v_footer');
    }

}
