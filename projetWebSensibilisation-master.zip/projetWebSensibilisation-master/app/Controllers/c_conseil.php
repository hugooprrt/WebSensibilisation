<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class c_conseil extends BaseController
{
    public function index(): string
    {

        return
            view( 'v_header')
            .view('v_conseil')
            .view("v_footer");

    }

    public function voirConseil(): string
    {

        return
            view( 'v_header')
            .view('v_conseil')
            .view("v_footer");

    }

}