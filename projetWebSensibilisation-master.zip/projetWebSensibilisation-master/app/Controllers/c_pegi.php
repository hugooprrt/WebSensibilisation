<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\m_pegi;

class c_pegi extends BaseController
{
    public function index(): string
    {

        return
            view( 'v_header')
            .view('v_pegi')
            .view("v_footer");

    }

    public function ImagePegi() : String
    {
        $modelPegi = new m_pegi();
        //$data['recupImage'] = $modelPegi->getImagePegi();

        // Récupérez les données pour PEGI 3
        $data['recupImagePegi3'] = $modelPegi->getImagePegi(1);
        $data['recupinfoPegi3'] = $modelPegi->getImagePegi(1);

        // Récupérez les données pour PEGI 7
        $data['recupImagePegi7'] = $modelPegi->getImagePegi(2);
        $data['recupinfoPegi7'] = $modelPegi->getImagePegi(2);

        // Récupérez les données pour PEGI 12
        $data['recupImagePegi12'] = $modelPegi->getImagePegi(3);
        $data['recupinfoPegi12'] = $modelPegi->getImagePegi(3);

        // Récupérez les données pour PEGI 16
        $data['recupImagePegi16'] = $modelPegi->getImagePegi(4);
        $data['recupinfoPegi16'] = $modelPegi->getImagePegi(4);

        // Récupérez les données pour PEGI 18
        $data['recupImagePegi18'] = $modelPegi->getImagePegi(5);
        $data['recupinfoPegi18'] = $modelPegi->getImagePegi(5);

        // Récupérez les données pour bad-language
        $data['recupImageBadLanguage'] = $modelPegi->getImagePegi(7);
        $data['recupinfoBadLanguage'] = $modelPegi->getImagePegi(7);

        // Récupérez les données pour discrimination
        $data['recupImageDiscrimination'] = $modelPegi->getImagePegi(8);
        $data['recupinfoDiscrimination'] = $modelPegi->getImagePegi(8);

        // Récupérez les données pour drugs
        $data['recupImageDrugs'] = $modelPegi->getImagePegi(9);
        $data['recupinfoDrugs'] = $modelPegi->getImagePegi(9);

        // Récupérez les données pour fear
        $data['recupImageFear'] = $modelPegi->getImagePegi(10);
        $data['recupinfoFear'] = $modelPegi->getImagePegi(10);

        // Récupérez les données pour gambling
        $data['recupImageGambling'] = $modelPegi->getImagePegi(11);
        $data['recupinfoGambling'] = $modelPegi->getImagePegi(11);

        // Récupérez les données pour in-game-purchase
        $data['recupImageInGamePurchase'] = $modelPegi->getImagePegi(12);
        $data['recupinfoInGamePurchase'] = $modelPegi->getImagePegi(12);

        // Récupérez les données pour sexual
        $data['recupImageSexual'] = $modelPegi->getImagePegi(13);
        $data['recupinfoSexual'] = $modelPegi->getImagePegi(13);

        // Récupérez les données pour violence
        $data['recupImageViolence'] = $modelPegi->getImagePegi(14);
        $data['recupinfoViolence'] = $modelPegi->getImagePegi(14);




        return view('v_header')
            . view('v_pegi', $data)
            . view('v_footer');
    }

}