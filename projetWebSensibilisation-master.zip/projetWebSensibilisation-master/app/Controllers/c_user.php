<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\m_user;
use CodeIgniter\Config\Services;

class c_user extends BaseController
{
    public function index()
    {
        $data['titre'] = "Connexion ou inscription";
        $session = Services::session();

        if (session()->get('loginUser')) {
            $session->remove('loginUser');
            $session->destroy();
        }

        return view('v_header')
            . view('v_inscriConnex', $data)
            . view('v_footer');
    }


    public function connexion()
    {
        $validation = Services::validation();
        // gestion des règles de validation
        $rules = ['loginUser' => 'required|min_length[6]'
            , 'pwdUser' => 'required|min_length[12]'];
        //Gestion des messages d'erreurs
        $errors = ['loginUser' => ['required' => 'Login obligatoire'
            , 'min_length' => '6 car. Minimum']
            , 'pwdUser' => ['required' => 'Mot de passe obligatoire'
                , 'min_length' => '12 car. Mininmum']
        ];
        $validation->setRules($rules, $errors);
        if ($this->validate($rules, $errors)) {
            // mise en place de la gestion des sessions
            $session = Services::session();
            // controle du login dans la table user
            $loginUser = $this->request->getPost('loginUser');
            $model = new m_user();
            $controle = $model->verifUser($loginUser);
            // le login n'est pas trouvé
            if ($controle == false) {
                $data['titre'] = "Connexion impossible à " . $loginUser;
                $data['validation'] = $this->validator;
                // gestion des données de sessions
                $session->setFlashdata('resultConnect', 'Utilisateur non trouvé');
                return view('v_header')
                    . view('v_connexion', $data)
                    . view('v_footer');
            } else {
                var_dump($controle);
                // le login est trouvé !
                $pwdUser = $controle->pwdUser;
                // comparaison des mots de passe !
                $mdp = $this->request->getPost('pwdUser');
                //ils sont identiques
                $verifPwd = password_verify($mdp, $pwdUser);
                if ($verifPwd) {
                    // mise en place des sessions
                    $session->set('loginUser', $controle->loginUser);
                    $session->set('pwdUser', $controle->pwdUser);
                    return view('v_header')
                        . view('v_accueil')
                        . view('v_footer');
                } else {
                    // message , évidemment à ne pas laisser tel quel !
                    $data['titre'] = "Pb mot de passe : ";
                    $data['validation'] = $this->validator;
                    $session->setFlashdata('resultConnect', 'probleme d intentification Utilisateur');
                    return view('v_header')
                        . view('v_connexion', $data)
                        . view('v_footer');
                }
            }
        } else {
            // login et mot de passes ne respectent pas les règles attendues
            $data['titre'] = "Connexion impossible, Corriger votre saisie";
            $data['validation'] = $this->validator;
            $loginUser = $this->request->getPost('loginUser');
            return view('v_header')
                . view('v_connexion', $data)
                . view('v_footer');
        }
    }

    public function login()
    {
        $validation = Services::validation();

        // vérifie si il y a eu une méthode post
        if ($this->request->getMethod() === 'post') {
            // création des règles/codes d'erreurs
            $rules = ['loginUser' => 'required'
                , 'pwdUser' => 'required'];

            $errors = [
                'loginUser' => [
                    'required' => 'Ce champ est obligatoire.'
                ],
                'pwdUser' => [
                    'required' => 'Ce champ est obligatoire.'
                ],
            ];

            $validation->setRules($rules, $errors);

            if ($this->validate($rules, $errors)) {
                $session = Services::session();

                // stocke le mail et le mdp
                $connexion_login = $this->request->getPost('loginUser');
                $connexion_mdp = $this->request->getPost('pwdUser');

                $model = new m_user();

                // utilise la méthode loginUser du modèle m_user
                $user = $model->loginUser($connexion_login);

                if ($user === -1) {
                    // il n'y a pas d'utilisateur avec ce mail
                    return view('v_header')
                        . view('v_connexion', ['validation' => $validation, 'titre' => "Login ou mot de passe invalide"])
                        . view('v_footer');
                } else {
                    // Vérifier le mot de passe
                    $verifPwd = password_verify($connexion_mdp, $user->mot_de_passe);
                    if ($verifPwd) {
                        // Mot de passe correct
                        $session->set('loginUser', $connexion_login);
                        return redirect()->to(base_url("public/"));
                    } else {
                        // Mot de passe incorrect
                        return view('v_header')
                            . view('v_connexion', ['validation' => $validation, 'titre' => "Login ou mot de passe invalide"])
                            . view('v_footer');
                    }
                }
            } else {
                // Critères non respectés
                return view('v_header')
                    . view('v_connexion', ['validation' => $validation, 'titre' => "Connexion impossible, Corrige ta saisie"])
                    . view('v_footer');
            }
        } else {
            return view('v_header')
                . view('v_connexion', ['validation' => $validation, 'titre' => "Se connecter..."])
                . view('v_footer');
        }
    }

    public function inscription(): string
    {
        $controle = $this->request->getPost('submit');
        if (isset($controle) == false) {
            $data['titre'] = "inscrivez vous";
            $data['validation'] = Services::validation();
        } else {
            $validation = Services::validation();
            $rules = ['loginUser' => 'required|min_length[8]',
                'mailUser' => 'required|min_length[12]',
                'pwdUser' => 'required|min_length[8]'];

            $errors = [
                'loginUser' => ['required' => 'login obligatoire',
                    'min_length' => '8 car. Minimum'],
                'mailUser' => ['required' => 'mail obligatoire'],
                'pwdUser' => ['required' => 'mdp obligatoire']
            ];
            $validation->setRules($rules, $errors);
            if ($this->validate($rules, $errors)) {
                $mdp = $this->request->getPost('pwdUser');
                $mdpHash = password_hash($mdp, PASSWORD_DEFAULT);
                $donnees = array(
                    'prenomUser' => $this->request->getPost('prenomUser'),
                    'nomUser' => $this->request->getPost('nomUser'),
                    'ageUser' => $this->request->getPost('ageUser'),
                    'loginUser' => $this->request->getPost('loginUser'),
                    'pwdUser' => $mdpHash,
                    'mailUser' => $this->request->getPost('mailUser'),
                );
                $modelinscr = new m_user();

                $recup = $modelinscr->ajouterUser($donnees);

                if ($recup == 1062) {
                    $data['titre'] = "Ajout non effectué, le numéro existe déjà";

                }
                if ($recup == 1) {
                    $data['titre'] = 'Ajout bien effectué';
                } else {
                    $data['titre'] = "Rien";

                }

                $data['validation'] = $this->validator;
            } else {
                $data['titre'] = "Ajout Impossible";
                $data['validation'] = $this->validator;

            }
        }
        return view('v_header')
            . view('v_inscription', $data)
            . view('v_footer');
    }

    public function signUp()
    {
        $data['validation'] = Services::validation();

        $validation = Services::validation();

        // vérifie si il y a eu une méthode post
        if ($this->request->getMethod() === 'post') {
            // création des règles/codes d'erreurs
            $rules = ['loginUser' => 'required|min_length[8]',
                'mailUser' => 'required|min_length[12]',
                'pwdUser' => 'required|min_length[8]',
                'nomUser' => 'required',
                'prenomUser' => 'required',
                'ageUser' => 'required|greater_than_equal_to[0]'];

            $errors = [
                'loginUser' => [
                    'required' => 'login obligatoire',
                    'min_length' => '8 car. Minimum'
                ],
                'mailUser' => [
                    'required' => 'mail obligatoire',
                    'min_length' => '12 car. Minimum'
                ],
                'pwdUser' => [
                    'required' => 'mdp obligatoire',
                    'min_length' => '8 car. Minimum'
                ],
                'nomUser' => [
                    'required' => 'nom obligatoire'
                ],
                'prenomUser' => [
                    'required' => 'prénom obligatoire'
                ],
                'ageUser' => [
                    'required' => 'âge obligatoire',
                    'greater_than_equal_to' => 'L\'âge doit être supérieur ou égal à zéro'
                ]
            ];

            $validation->setRules($rules, $errors);

            if ($this->validate($rules, $errors)) {
                $session = Services::session();

                // stocke les différentes informations utilisateurs
                $inscrire_prenom = $this->request->getPost('prenomUser');
                $inscrire_nom = $this->request->getPost('nomUser');
                $inscrire_age = $this->request->getPost('ageUser');
                $inscrire_login = $this->request->getPost('loginUser');
                $inscrire_mail = $this->request->getPost('mailUser');
                $inscrire_mdp = $this->request->getPost('pwdUser');

                // hash du mdp
                $inscrire_hashPwd = password_hash($inscrire_mdp, PASSWORD_DEFAULT);

                $model = new m_user();

                // utilise la méthode createUser du modèle m_user
                $insert = $model->createUser($inscrire_prenom, $inscrire_nom, $inscrire_age, $inscrire_login, $inscrire_mail, $inscrire_hashPwd);

                if ($insert === '-1') {
                    // indique que le pseudo est déjà utilisé
                    return view('v_header')
                        . view('utilisateur/v_inscription', ['validation' => $this->validator, 'titre' => "Pseudo déjà utilisé !"])
                        . view('v_footer');
                } elseif ($insert === '-2') {
                    // indique que le mail est déjà utilisé
                    return view('v_header')
                        . view('utilisateur/v_inscription', ['validation' => $this->validator, 'titre' => "Mail déjà utilisé !"])
                        . view('v_footer');
                } else {
                    // inscription réussie
                    $session->set('loginUser', $inscrire_login);
                    return redirect()->to(base_url("public/"));
                }
            } else {
                // ne respecte pas les conditions
                return view('v_header')
                    . view('v_inscription', ['validation' => $this->validator, 'titre' => "Inscription impossible, Corrige ta saisie"])
                    . view('v_footer');
            }
        } else {
            return view('v_header')
                . view('v_inscription', ['validation' => $validation, 'titre' => "S'inscrire..."])
                . view('v_footer');
        }
    }
}