<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use CodeIgniter\Config\Services;

class c_password extends BaseController
{
    public function index() : string
    {
        // Charger la bibliothèque de validation
        $validation = Services::validation();

        // Définir les règles de validation
        $rules = [
            'password' => 'required|min_length[12]|regex_match[/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)(?=.*[^a-zA-Z\d])[\s\S]{8,}$/]',
        ];

        // Messages d'erreur personnalisés
        $errors = [
            'password' => [
                'required' => 'Entrez votre mot de passe pour le tester',
                'min_length' => 'Le mot de passe doit contenir au moins 12 caractères.',
                'regex_match' => 'Le mot de passe doit contenir des lettres majuscules, des lettres minuscules, des chiffres et des caractères spéciaux.'
            ],
        ];

        // Configurer la bibliothèque de validation
        $validation->setRules($rules, $errors);

        // Exécuter la validation
        if ($validation->run($this->request->getPost())) {
            $data['rep'] = "Le mot de passe est robuste!";
        } else {
            // Stocker les erreurs de validation dans le tableau de données
            $data['rep'] = $validation->listErrors();
        }

        return view('v_header')
            . view('v_testMDP', $data)
            . view('v_footer');
    }
}