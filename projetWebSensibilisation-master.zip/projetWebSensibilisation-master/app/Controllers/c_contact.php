<?php

namespace App\Controllers;

use App\Controllers\BaseController;

class c_contact extends BaseController
{
    public function index()
    {
        return view('v_header').
            view('v_contact').
            view('v_footer');
    }

    public function submitForm()
    {
        $model = new m_contact();

        $data = [
            'nom' => $this->request->getPost('nom'),
            'email' => $this->request->getPost('email'),
            'message' => $this->request->getPost('message')
        ];

        if ($model->insert($data)) {
            return redirect()->to('/contact')->with('success', 'Votre message a été envoyé avec succès.');
        } else {
            return redirect()->to('/contact')->with('error', 'Une erreur s\'est produite. Veuillez réessayer.');
        }
    }
}