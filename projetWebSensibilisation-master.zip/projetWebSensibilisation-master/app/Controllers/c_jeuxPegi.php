<?php

namespace App\Controllers;

use App\Controllers\BaseController;
use App\Models\m_jeuxPegi;
use App\Models\m_pegi;

class c_jeuxPegi extends BaseController
{
    public function index(): string
    {

        return
            view( 'v_header')
            .view('v_jeuxPegi')
            .view("v_footer");

    }
    public function ImagePegiJeux() : String
    {
        $modelPegi = new m_jeuxPegi();
        //$data['recupImage'] = $modelPegi->getImagePegi();

        // Récupérez les données pour PEGI 3
        $data['recupImageJeux3'] = $modelPegi->getImagePegiJeux(15);

        // Récupérez les données pour PEGI 7
        $data['recupImageJeux7'] = $modelPegi->getImagePegiJeux(17);

        // Récupérez les données pour PEGI 12
        $data['recupImageJeux12'] = $modelPegi->getImagePegiJeux(20);

        // Récupérez les données pour PEGI 16
        $data['recupImageJeux16'] = $modelPegi->getImagePegiJeux(21);

        // Récupérez les données pour PEGI 18
        $data['recupImageJeux18'] = $modelPegi->getImagePegiJeux(24);

        // Récupérez les données pour PEGI 3
        $data['recupImagePegi3'] = $modelPegi->getImagePegiJeux(1);

        // Récupérez les données pour PEGI 7
        $data['recupImagePegi7'] = $modelPegi->getImagePegiJeux(2);

        // Récupérez les données pour PEGI 12
        $data['recupImagePegi12'] = $modelPegi->getImagePegiJeux(3);

        // Récupérez les données pour PEGI 16
        $data['recupImagePegi16'] = $modelPegi->getImagePegiJeux(4);

        // Récupérez les données pour PEGI 18
        $data['recupImagePegi18'] = $modelPegi->getImagePegiJeux(5);

        return view('v_header')
            . view('v_jeuxPegi', $data)
            . view('v_footer');
    }
}