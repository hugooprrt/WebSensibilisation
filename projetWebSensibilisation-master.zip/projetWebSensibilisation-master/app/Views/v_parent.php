<body>
<div class="container">
    <h1 class="quiz-title">Quiz - Thème Parent</h1>

    <div class="quiz-container">
        <?php
        $currentQuestionIndex = session('quiz_parent')['current_question'];
        $selectedQuestions = session('selected_questions');
        $totalQuestions = count($selectedQuestions);

        if ($currentQuestionIndex < $totalQuestions) :
            $currentQuestion = $selectedQuestions[$currentQuestionIndex];
            ?>
            <div>
                <p class="quiz-question"><?= $currentQuestion['question']; ?></p>
                <?= form_open(base_url('public/quizParent'), 'method="post"'); ?>
                <input type="hidden" name="answer" value="true">
                <button class="quiz-button" type="submit">Vrai</button>
                <?= form_close(); ?>
                <br>
                <br>
                <?= form_open(base_url('public/quizParent'), 'method="post"'); ?>
                <input type="hidden" name="answer" value="false">
                <button class="quiz-button" type="submit">Faux</button>
                <?= form_close(); ?>
            </div>
        <?php else : ?>
            <p class="quiz-result">Quiz terminé. Vous avez <?= session('quiz_parent')['correct_answers']; ?> réponses
                correctes.</p>
        <?php endif; ?>
    </div>
</div>
</body>



