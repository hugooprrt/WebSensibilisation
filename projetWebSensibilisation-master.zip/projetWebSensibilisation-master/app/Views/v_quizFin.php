<body>
<div class="container">
    <h1>Résultat du Quiz</h1>
    <p>Votre score final est :</p>
    <p class="score"><?= $correct_answers ?> / 15</p>
    <p>Merci d'avoir participé !</p>
</div>
</body>