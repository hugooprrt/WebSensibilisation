<div class="container">
    <div class="game-board">
        <!-- Zone de dépôt des images de PEGI -->
        <div class="pegis-dropzone" id="pegis-dropzone" ondrop="drop(event)" ondragover="allowDrop(event)">
            <p>Déposez les images PEGI ici</p>
        </div>
    </div>
    <div class="pegis">
        <div class="pegi" id="pegi3" draggable="true" ondragstart="drag(event)">
            <!-- Images PEGI à glisser -->
            <?php
            if ($recupImageJeux3 == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
            ?>

            <div class="field-image image">
                <?php
                // Concaténez le chemin avec le nom de l'image depuis la base de données
                $Jeux3Chemin = "/public/image/" . $recupImageJeux3['jeux_image'];
                $proprieteImage = [
                    'src' => $Jeux3Chemin,
                    'class' => 'imgpEGI3'
                ];
                ?>
                <?php
            }
            ?>
        </div>
        <img src="<?$proprieteImage?>"  class="pegi" id="pegi3" draggable="true" ondragstart="drag(event)">
        <img src="pegi7.png" class="pegi" id="pegi7" draggable="true" ondragstart="drag(event)">
        <img src="pegi12.png" class="pegi" id="pegi12" draggable="true" ondragstart="drag(event)">
        <!-- Ajoutez plus d'images PEGI au besoin -->
    </div>
    <div class="games">
        <!-- Images des jeux à associer -->
        <img src="rocketLeague.jpg" class="game" id="game1" ondrop="drop(event)" ondragover="allowDrop(event)">
        <img src="fifa24.jpg" class="game" id="game2" ondrop="drop(event)" ondragover="allowDrop(event)">
        <img src="fortnite.jpg" class="game" id="game3" ondrop="drop(event)" ondragover="allowDrop(event)">
        <!-- Ajoutez plus d'images de jeux au besoin -->
    </div>
</div>