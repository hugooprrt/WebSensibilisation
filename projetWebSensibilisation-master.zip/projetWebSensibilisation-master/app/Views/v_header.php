<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sensibilisation</title>

    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.1/css/all.min.css">
</head>
<?= link_tag('/public/css/cssMdp.css'); ?>
<?= link_tag('/public/js/style.js'); ?>

<body>

<nav class="navbar navbar-expand-lg navbar-dark bg-dark">
    <a class="navbar-brand" href="#">Sensibilisation</a>
    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarNav" aria-controls="navbarNav"
            aria-expanded="false" aria-label="Toggle navigation">
        <span class="navbar-toggler-icon"></span>
    </button>
    <div class="collapse navbar-collapse" id="navbarNav">
        <ul class="navbar-nav">
            <li class="nav-item active">
                <a class="nav-link" <?= anchor(base_url() . 'public/', "Accueil") ?> </a>
            </li>
            <li class="nav-item">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                   aria-haspopup="true" aria-expanded="false">
                    Jeux Vidéo
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" <?= anchor(base_url() . 'public/informer', "S'informer") ?> </a>
                    <a class="dropdown-item" <?= anchor(base_url() . 'public/jeux', "Jeux PEGI") ?> </a>
                </div>
            </li>
            <li class="nav-item">
                <a class="nav-link" <?= anchor(base_url() . 'public/pratiques', "Bonnes Pratiques") ?> </a>
            </li>
            <li class="nav-item">
                <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button" data-toggle="dropdown"
                   aria-haspopup="true" aria-expanded="false">
                    Divertissement
                </a>
                <div class="dropdown-menu" aria-labelledby="navbarDropdown">
                    <a class="dropdown-item" <?= anchor(base_url() . 'public/lesMdp', "Tester son MDP") ?> </a>
                    <a class="dropdown-item" <?= anchor(base_url() . 'public/quiz', "Quiz") ?> </a>
                </div>
            </li>
            <?php
            if (session()->get('loginUser')){
            ?>
            <li class="nav-item">
                <a class="nav-link" <?= anchor(base_url() . 'public/contact', "Contact") ?> </a>
            </li>
            <?php
            }
            ?>
            <li class="nav-item">
                <?php
                if (!session()->get('loginUser')){
                ?>
                <a class="nav-link" <?= anchor(base_url() . 'public/connexion', "Connexion") ?> </a>
                <?php
                }
                else {?>
                    <a class="nav-link" <?= anchor(base_url() . 'public/connexion', "Deconnexion") ?> </a>
                <?php
                }
                ?>
            </li>
        </ul>
    </div>

    <!-- imporatation des éléments -->
    <script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.2/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
</nav>



