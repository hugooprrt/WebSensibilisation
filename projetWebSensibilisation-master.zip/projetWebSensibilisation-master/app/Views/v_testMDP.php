<body>
<div class="container">
    <h1>Test ton mot de passe !</h1>
    <p>Un mot de passe robuste est crucial pour sécuriser tes comptes en ligne.</p>
    <p>Les risques d'un mot de passe faible peuvent inclure :</p>
    <ul>
        <li>Accès non autorisé à tes informations personnelles.</li>
        <li>Perte de contrôle sur tes comptes en ligne.</li>
        <li>Exposition à des attaques de phishing et de piratage.</li>
    </ul>
    <h2>Vérifions ensemble !</h2>
    <?= form_open(base_url('public/lesMdp'), 'method="post"'); ?>
    <label for="mdp">Mot de passe :</label>
    <input type="password" id="password" name="password" required>
    <input type="submit" value="Vérifier">
    <?= form_close(); ?>
    <h2><?= $rep ?></h2>
</div>
</body>