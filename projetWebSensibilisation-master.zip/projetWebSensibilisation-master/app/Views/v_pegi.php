

<header>
    <h1>Informez vous sur les PEGI !</h1>
    <p>PEGI permet aux parents de prendre des décisions éclairées lors de l’achat de jeux vidéo.</p>
</header>


<section class="scam-info">
    <h2><i class="titre1"></i> Qu'est-ce qu'un PEGI ?</h2>
    <div class="info-content">
        <p>Le système PEGI de classification par âge des jeux vidéo est utilisé dans 38 pays européens. La classification
            par âge confirme que le jeu est approprié à l’âge du joueur. La classification PEGI se base sur le caractère
            adapté d’un jeu à une classe d’âge, et non sur le niveau de difficulté.</p>
    </div>
</section>

<div class="intro right">
    <div class="intro-content">

        <div class="field-age-labels-title string">
            DEUX NIVEAUX D’INFORMATION COMME GUIDE: LES LABELS D’ÂGE PEGI
        </div>
    </div>
</div>
<div class="container">
    <article data-history-node-id="5" role="article" class="label-descriptor pegi-7">
        <div class="article-content">
            <h3>
                <span>PEGI 3</span>
            </h3>

            <?php
            if ($recupImagePegi3 == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $Pegi3Chemin = "/public/image/" . $recupImagePegi3['pegi_image'];
                    $proprieteImage = [
                        'src' => $Pegi3Chemin,
                        'class' => 'imgpEGI3'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoPegi3['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>



    <article data-history-node-id="5" role="article" class="label-descriptor pegi-7">
        <div class="article-content">
            <h3>
                <span>PEGI 7</span>
            </h3>

            <?php
            if ($recupImagePegi7 == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $Pegi7Chemin = "/public/image/" . $recupImagePegi7['pegi_image'];
                    $proprieteImage = [
                        'src' => $Pegi7Chemin,
                        'class' => 'imgpEGI7'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoPegi7['pegi_explication']; ?></p>
                </div>
                <?php
            }
            ?>
        </div>
    </article>


    <article data-history-node-id="5" role="article" class="label-descriptor pegi-7">
        <div class="article-content">
            <h3>
                <span>PEGI 12</span>
            </h3>
            <?php
            if ($recupImagePegi12 == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $Pegi12Chemin = "/public/image/" . $recupImagePegi12['pegi_image'];
                    $proprieteImage = [
                        'src' => $Pegi12Chemin,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoPegi12['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>
    <article data-history-node-id="5" role="article" class="label-descriptor pegi-7">
        <div class="article-content">
            <h3>
                <span>PEGI 16</span>
            </h3>
            <?php
            if ($recupImagePegi16 == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $Pegi16Chemin = "/public/image/" . $recupImagePegi16['pegi_image'];
                    $proprieteImage = [
                        'src' => $Pegi16Chemin,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoPegi16['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>

    <article data-history-node-id="5" role="article" class="label-descriptor pegi-7">
        <div class="article-content">
            <h3>
                <span>PEGI 18</span>
            </h3>
            <?php
            if ($recupImagePegi18 == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $Pegi18Chemin = "/public/image/" . $recupImagePegi18['pegi_image'];
                    $proprieteImage = [
                        'src' => $Pegi18Chemin,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoPegi18['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>

    <article data-history-node-id="10" role="article" class="label-descriptor langage-grossier">
        <div class="article-content">

            <h3>
                <span>Langage Grossier</span>
            </h3>
            <?php
            if ($recupImageBadLanguage == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $PegiCheminBadLanguage = "/public/image/" . $recupImageBadLanguage['pegi_image'];
                    $proprieteImage = [
                        'src' => $PegiCheminBadLanguage,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoBadLanguage['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>

    <article data-history-node-id="10" role="article" class="label-descriptor langage-grossier">
        <div class="article-content">
            <h3>
                <span>Discrimination</span>
            </h3>
            <?php
            if ($recupImageDiscrimination == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $PegiCheminDiscrimination = "/public/image/" . $recupImageDiscrimination['pegi_image'];
                    $proprieteImage = [
                        'src' => $PegiCheminDiscrimination,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoDiscrimination['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>

    <article data-history-node-id="10" role="article" class="label-descriptor langage-grossier">
        <div class="article-content">

            <h3>
                <span>Drogues</span>
            </h3>

            <?php
            if ($recupImageDrugs == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $PegiCheminDrogues = "/public/image/" . $recupImageDrugs['pegi_image'];
                    $proprieteImage = [
                        'src' => $PegiCheminDrogues,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoDrugs['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>


    <article data-history-node-id="10" role="article" class="label-descriptor langage-grossier">
        <div class="article-content">

            <h3>
                <span>Peur</span>
            </h3>
            <?php
            if ($recupImageFear == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $PegiCheminPeur = "/public/image/" . $recupImageFear['pegi_image'];
                    $proprieteImage = [
                        'src' => $PegiCheminPeur,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoFear['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>


    <article data-history-node-id="10" role="article" class="label-descriptor langage-grossier">
        <div class="article-content">

            <h3>
                <span>Jeux de hasard</span>
            </h3>
            <?php
            if ($recupImageGambling == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $PegiCheminhasard = "/public/image/" . $recupImageGambling['pegi_image'];
                    $proprieteImage = [
                        'src' => $PegiCheminhasard,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoGambling['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>

    <article data-history-node-id="15" role="article" class="label-descriptor sexe">
        <div class="article-content">

            <h3>
                <span>Sexe</span>
            </h3>
            <?php
            if ($recupImageSexual == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $PegiCheminSexe = "/public/image/" . $recupImageSexual['pegi_image'];
                    $proprieteImage = [
                        'src' => $PegiCheminSexe,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoSexual['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>

    <article data-history-node-id="16" role="article" class="label-descriptor violence">
        <div class="article-content">

            <h3>
                <span>Violence</span>
            </h3>
            <?php
            if ($recupImageViolence == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $PegiCheminViolence = "/public/image/" . $recupImageViolence['pegi_image'];
                    $proprieteImage = [
                        'src' => $PegiCheminViolence,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoViolence['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>

    <article data-history-node-id="63" role="article" class="label-descriptor in-game-purchases">
        <div class="article-content">

            <h3>
                <span>In-Game Purchases</span>
            </h3>
            <?php
            if ($recupImageInGamePurchase == false) {
                echo "Aucune image disponible pour le moment.";
            } else {
                ?>

                <div class="field-image image">
                    <?php
                    // Concaténez le chemin avec le nom de l'image depuis la base de données
                    $PegiCheminPurchase = "/public/image/" . $recupImageInGamePurchase['pegi_image'];
                    $proprieteImage = [
                        'src' => $PegiCheminPurchase,
                        'class' => 'imgpEGI12'
                    ];

                    echo img($proprieteImage);
                    ?>
                </div>
                <!-- Ajoutez cette section pour afficher les informations de la base de données -->
                <div class="pegi-info">
                    <p><?php echo $recupinfoInGamePurchase['pegi_explication']; ?></p>
                </div>

                <?php
            }
            ?>
        </div>
    </article>
</div>

<script>
    function toggleScam(scam) {
        scam.classList.toggle('active');
    }
</script>


