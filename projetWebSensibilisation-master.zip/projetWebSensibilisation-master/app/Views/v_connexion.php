<div class="corps">
    <h1> <?= $titre; ?> </h1>
    <?php
    $session = \Config\Services::session();

    if(!$session->getFlashdata('resultConnect'))
    {
        ?>
        <h4>Veuillez vous identifier...</h4>
        <?php
    } else {
    ?>
    <h4>
        <?php
        echo $session->getFlashdata('resultConnect');
        }
        ?>
    </h4>
    <?php
    echo form_open(base_url(). "public/login");

    echo '<p>';
    echo form_label('Login :');

    $data = array(
        'name' => 'loginUser',
        'id' => 'loginUser',
        'value' => set_value('login'),
        'size' => 40,
        'type' => 'text',
        'placeholder' => 'Login'
    );

    echo form_input($data);
    echo "</p>"."<p>";
    echo $validation->getError('loginUser');
    echo "</p>"."<p>";

    echo form_label('Mot de passe :');

    $data = array(
        'name' => 'pwdUser',
        'id' => 'pwdUser',
        'value' => set_value('pwdUser'),
        'size' => 40,
        'type' => 'password',
        'placeholder' => 'mot de passe'
    );

    echo form_password($data);
    echo "</p>"."<p>";
    echo $validation->getError('pwdUser');
    echo "</p>"."<p>";

    $data = array(
        'name' => 'submit',
        'id' => 'submit',
        'content' => 'VALIDER',
        'type' => 'submit'
    );

    echo form_button($data);
    echo "</p>";
    ?>
</div>

