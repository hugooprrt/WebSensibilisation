<div class="corps">
    <h1>
        <?php
        //pas de session en cours
        if (!session()->get('loginUser')){ ?>
            <?= $titre ?>
        <?php }else{ ?>
            Deconnexion
        <?php } ?>
    </h1>
    <!-- contenue de la page inscription connexion -->

    <div class="menu">
        <ul>
            <?php
            //pas de session en cours
            if (!session()->get('loginUser')){ ?>
                <li>
                    <h2 class="btn_menu">
                        <?=anchor(base_url().'public/login','Se connecter')?>
                    </h2>

                    <h2 class="btn_menu">
                        <?=anchor(base_url().'public/signUp', "S'inscrire")?>
                    </h2>
                </li>
            <?php }else{ ?>
                <li>
                    <h2 class="btn_menu">
                        <?=anchor(base_url().'public/deconnexion','Me deconnecter')?>
                    </h2>
                </li>
            <?php } ?>

        </ul>
    </div>
