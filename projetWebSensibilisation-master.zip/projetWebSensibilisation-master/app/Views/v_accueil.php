
<header>
    <h1>Bienvenue sur notre site de sensibilisation</h1>
    <p>Restons informés pour une utilisation responsable de la technologie.</p>
</header>

<section class="key-figures">
    <div class="figure">
        <h2>Temps d'écran moyen</h2>
        <p>Les jeunes passent en moyenne <strong>6 heures par jour</strong> devant un écran.</p>
    </div>
    <div class="figure">
        <h2>Cyber sécurité</h2>
        <p>Il est essentiel de s'informer sur la cyber sécurité pour se protéger en ligne.</p>
    </div>
    <div class="figure">
        <h2>Utilisation des réseaux sociaux</h2>
        <p>Près de <strong>70%</strong> des adolescents utilisent les réseaux sociaux au quotidien.</p>
    </div>
</section>

<section class="scam-info">
    <h2><i class="fas fa-info-circle"></i> Qu'est-ce qu'une escroquerie ?</h2>
    <div class="info-content">
        <p>Une escroquerie est une pratique frauduleuse visant à tromper une personne pour lui soutirer de l'argent
            ou des biens. Un exemple connu est l'arnaque par phishing, où un fraudeur tente de vous convaincre de divulguer
            des informations confidentielles, telles que des identifiants de connexion ou des informations de carte de crédit,
            en se faisant passer pour une entité légitime.</p>
    </div>
</section>

<section class="scam-info">
    <h2><i class="fas fa-exclamation-triangle"></i> Escroqueries Connues</h2>
    <div class="scams-container">
        <div class="scam" onclick="toggleScam(this)">
            <div class="scams-container">
                <?php
                if (empty($nomEscroquerie)) {
                    echo '<p>Aucune escroquerie disponible pour le moment.</p>';
                } else {
                    ?>
                    <div class="scam" onclick="toggleScam(this)">
                        <h3><i class="fas fa-info-circle"></i> <?php echo $nomEscroquerie; ?></h3>
                        <div class="scam-content">
                            <p><?php echo $expEscroquerie; ?></p>
                        </div>
                    </div>
                    <?php
                }
                ?>
            </div>
        </div>
    </div>

</section>

<script>
    function toggleScam(scam) {
        scam.classList.toggle('active');
    }
</script>

