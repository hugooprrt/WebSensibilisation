<div class="corps">
    <h1> <?= $titre; ?>  </h1>

    <?php
    $session = \Config\Services::session();

    if(!$session->getFlashdata('resultConnect'))
    {
        ?>
        <h4>Veuillez vous inscrire...</h4>
        <?php
    } else {
    ?>
    <h4>
        <?php
        echo $session->getFlashdata('resultConnect');
        }
        ?>
    </h4>

    <?php echo form_open(base_url(). "public/signUp");

    echo '<p>';
    echo form_label('Prenom :');

    $data = array(
        'name' => 'prenomUser',
        'id' => 'prenomUser',
        'value' => set_value('prenom'),
        'size' => 40,
        'type' => 'text',
        'placeholder' => 'prenom'
    );

    echo form_input($data);
    echo "</p>"."<p>";
    echo $validation->getError('prenomUser');
    echo "</p>"."<p>";

    echo '<p>';
    echo form_label('Nom :');

    $data = array(
        'name' => 'nomUser',
        'id' => 'nomUser',
        'value' => set_value('nom'),
        'size' => 40,
        'type' => 'text',
        'placeholder' => 'nom'
    );

    echo form_input($data);
    echo "</p>"."<p>";
    echo $validation->getError('nomUser');
    echo "</p>"."<p>";

    echo '<p>';
    echo form_label('Age :');

    $data = array(
        'name' => 'ageUser',
        'id' => 'ageUser',
        'value' => set_value('age'),
        'size' => 40,
        'type' => 'number',
        'placeholder' => 'Age'
    );

    echo form_input($data);
    echo "</p>"."<p>";
    echo $validation->getError('ageUser');
    echo "</p>"."<p>";

    echo '<p>';
    echo form_label('Login :');

    $data = array(
        'name' => 'loginUser',
        'id' => 'loginUser',
        'value' => set_value('login'),
        'size' => 40,
        'type' => 'text',
        'placeholder' => 'Login'
    );

    echo form_input($data);
    echo "</p>"."<p>";
    echo $validation->getError('loginUser');
    echo "</p>"."<p>";

    echo form_label('Mail :');

    $data = array(
        'name' => 'mailUser',
        'id' => 'mailUser',
        'value' => set_value('mail'),
        'size' => 40,
        'type' => 'texte',
        'placeholder' => 'mail'
    );

    echo form_input($data);
    echo "</p>"."<p>";

    echo $validation->getError('mailUser');

    echo "</p>"."<p>";

    echo form_label('Mdp :');

    $data = array(
        'name' => 'pwdUser',
        'id' => 'pwdUser',
        'value' => set_value('mdp'),
        'size' => 40,
        'type' => 'password',
        'placeholder' => 'mot de passe'

    );

    echo form_input($data);
    echo "</p>"."<p>";
    echo $validation->getError('pwdUser');
    echo "</p>"."<p>";



    $data = array(
        'name' => 'submit',
        'id' => 'submit',
        'content' => 'VALIDER',
        'type' => 'submit'
    );

    echo form_button($data);
    echo "</p>";

    ?>
</div>
