<header>
    <h1>Conseils pour la Protection des Données</h1>
</header>

<section id="conseils-parents">
    <h2>Conseils aux Parents</h2>
    <ul>
        <li><strong>Sensibilisez vos enfants :</strong> Parlez-leur des dangers potentiels et de l'importance de protéger leurs informations personnelles.</li>
        <li><strong>Établissez des règles :</strong> Définissez des règles claires sur l'utilisation d'Internet et des réseaux sociaux.</li>
        <li><strong>Utilisez des filtres parentaux :</strong> Installez des outils de filtrage pour contrôler le contenu auquel vos enfants ont accès.</li>
        <li><strong>Encouragez des mots de passe forts :</strong> Apprenez-leur à créer des mots de passe sécurisés et à ne pas les partager.</li>
        <li><strong>Surveillez l'activité en ligne :</strong> Gardez un œil sur les activités en ligne de vos enfants sans les envahir.</li>
    </ul>
</section>

<section id="conseils-enfants">
    <h2>Conseils aux Enfants</h2>
    <ul>
        <li><strong>Protégez vos informations personnelles :</strong> Ne partagez pas d'informations sensibles en ligne, comme votre adresse, numéro de téléphone, etc.</li>
        <li><strong>Ne communiquez qu'avec des personnes de confiance :</strong> N'acceptez pas d'invitations ou de demandes d'amis de personnes que vous ne connaissez pas dans la vie réelle.</li>
        <li><strong>Utilisez les paramètres de confidentialité :</strong> Apprenez à configurer les paramètres de confidentialité sur les réseaux sociaux pour contrôler qui peut voir vos informations.</li>
        <li><strong>Signalez tout comportement inapproprié :</strong> Si quelque chose vous semble étrange ou inapproprié en ligne, signalez-le à un parent ou à un adulte de confiance.</li>
        <li><strong>Soyez conscient des dangers :</strong> Apprenez à reconnaître les signes de cyberharcèlement, d'arnaque en ligne, et d'autres menaces potentielles.</li>
    </ul>
</section>

