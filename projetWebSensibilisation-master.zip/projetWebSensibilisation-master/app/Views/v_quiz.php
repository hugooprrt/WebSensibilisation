<body>
<div class="container">
    <h1>Quiz</h1>
    <p>Choisissez un thème :</p>
    <?= form_open(base_url('public/quizParent')); ?>
    <input type="submit" value="Thème parent">
    <?= form_close(); ?>

    <br>
    <br>

    <?= form_open(base_url('public/quiz/enfant')); ?>
    <input type="submit" value="Thème enfant">
    <?= form_close(); ?>
</div>
</body>