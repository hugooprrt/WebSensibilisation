<?php

use CodeIgniter\Router\RouteCollection;

/**
 * @var RouteCollection $routes
 */
//$routes->get('/', 'Home::index');
$routes->get('/', 'c_accueil::index');
$routes->match(['get', 'post'],'/escroquerie', 'c_accueil::LesEscroqueries');
$routes->match(['get', 'post'],'/lesMdp', 'c_password::index');

$routes->get('/quiz', 'c_quiz::index');

$routes->match(['get', 'post'],'/quizParent', 'c_quiz::parent');

$routes->match(['get', 'post'],'quiz/enfant', 'c_quiz::enfant');

$routes->match(['get', 'post'],'/informer', 'c_pegi::ImagePegi');
$routes->match(['get', 'post'],'/jeux', 'c_pegi::index');

$routes->get('/connexion', 'c_user::index');
$routes->match(['get', 'post'],'/login', 'c_user::login');
$routes->match(['get', 'post'],'/seConnecter', 'c_user::connexion');
$routes->match(['get', 'post'],'/signUp', 'c_user::signUp');
$routes->match(['get', 'post'],'/inscription', 'c_user::inscription');
$routes->match(['get', 'post'],'/deconnexion', 'c_user::deconnexion');

//nouveau

$routes->match(['get', 'post'],'/jeux', 'c_pegi::index');
$routes->match(['get', 'post'],'/pratiques', 'c_conseil::voirConseil');